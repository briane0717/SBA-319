const React = require("react");

class Edit extends React.Component {
  render() {
    const user = this.props.user; // Access the user data passed from the route
    return (
      <form action={`/users/${user._id}?_method=PUT`} method="POST">
        User Name:{" "}
        <input
          type="text"
          name="userName"
          defaultValue={user.userName} // Use 'user.userName' here
        />
        <br />
        Email:{" "}
        <input
          type="email"
          name="email"
          defaultValue={user.email} // Use 'user.email' here
        />
        <br />
        Age:{" "}
        <input
          type="number"
          name="age"
          defaultValue={user.age} // Use 'user.age' here
        />
        <br />
        Active:{" "}
        <input
          type="checkbox"
          name="isActive"
          defaultChecked={user.isActive} // Use 'user.isActive' here
        />
        <br />
        <button type="submit">Edit User</button>
      </form>
    );
  }
}

module.exports = Edit;
